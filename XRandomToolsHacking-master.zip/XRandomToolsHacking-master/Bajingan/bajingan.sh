#!/system/xbin/bash
clear
blue='\e[1;34m'
green='\e[1;32m'                                        
purple='\[1;35m'
cyan='\e[1;36m'
red='\e[1;31m'
white='\e[1;37m'                                           
yellow='\e[1;33m'
sleep 1
echo "\033[32;1m=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*="
toilet -f standard -F gay "ToolsB4j1n64n2"
echo "\033[31;1m=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*="
echo ""              
echo "Author : " Mr.B4J1N64N"
" Team : " DARKNESS CYBER TEAM"
echo " Kontak Me :  083108271123"
sleep 1
echo "ThanksTo:"
echo "Allmember DARKNESS CYBER TEAM"
echo "\033[33;1m[============================[>"
echo ""
sleep 1
echo "\033[32;1m Silahkan Pilih Tools Yang mau Kamu pake:)?:"
echo "[================================================{>"
sleep 1
echo "1.> SpamTokopedia"
sleep 1
echo "\033[31;1m[===============================================]>"
sleep 1
echo "2.> SpamTelkomnyet"
sleep 1
echo "\033[37;1m[===============================================]>"
echo "3.> SpamMatahari Mall"
sleep 1
echo "\033[33;1m[===============================================]>"
echo "4.> SpamHooqTV"
sleep 1
echo "\033[35;1m[===============================================]>"
echo "5.> SpamKFC"
sleep 1
echo "\033[36;1m[===============================================]>"
echo "6.> SpamPHD"
sleep 1
echo "\033[31;1m[===============================================]>"
echo "7.> SpamWhiskas"
sleep 1
echo "\033[32;1m[===============================================]>"
echo "8.> SpamZiPAY"
sleep 1
echo "\033[36;1m[===============================================]>"
echo "9.> Nyari CC buat Carding"
sleep 1
echo "\033[34;1m[===============================================]>"
echo "10.> Spam Akun Gmail"
sleep 1
echo "\033[37;1m[===============================================]>"
echo "11.> Whois LookUp"
sleep 1
echo "\033[35;1m[===============================================]>"
echo "12.> Upload Admin Finder"
sleep 1
echo "\033[31;1m[===============================================]>"
echo "13.> Script Deface Creator"
sleep 1
echo "\033[32;1m[===============================================]>"
echo "14.> ReConDog"
sleep 1
echo "\033[37;1m[===============================================]>"
echo "15.> Admin Login Finder"
sleep 1
echo "\033[33;1m[===============================================]>"
echo "16.> Virus VbugMaker Creator"
sleep 1
echo "\033[34;1m[===============================================]>"
echo "17.> Html Downloader"
sleep 1
echo "\033[36;1m[===============================================]>"
echo "18.> Autolike Facebook"
sleep 1
echo "\033[31;1m[===============================================]>"
echo "19.> Facebook Auto_Reaction"
sleep 1
echo "\033[32;1m[===============================================]>"
echo "20.> Bot Komentar Facebook"
sleep 1
echo "\033[33;1m[===============================================]>"
echo "21.> Install txtool"
sleep 1
echo "\033[34;1m[===============================================]>"
sleep 1
echo "22.> install sqlscan"
echo "\033[37;1m[===============================================]>"
sleep 1 
echo "23.> install hash-buster"
echo "\033[33;1m[===============================================]>"
sleep 1
echo "24.> Install Red_Hawk"
echo "\033[34;1m[===============================================]>"
sleep 1
echo "25.> Install Torshammer buat DDOS website"
echo "\033[35;1m[===============================================]>"
sleep 1
echo "26.> Install LITEDDOS buat DDOS website"
echo "\033[36;1m[===============================================]>"
sleep 1
echo "27.> Install Hunner Framework"
echo "\033[31;1m[===============================================]>"
sleep 1
echo "28.> Install Sqlmap"
echo "\033[34;1m[===============================================]>"
sleep 1
echo "29.> Install 4wsectools"
echo "\033[37;1m[===============================================]>"
sleep 1
echo "30.> Install Lazymux"
echo "\033[31;1m[===============================================]>"
sleep 1
echo "31.> Mempercepat / Menstabilkan Jaringan/sinyal"
echo "\033[35;1m[===============================================]>"
sleep 1
echo "32.> Mempercepat / menstabilkan jaringan 2"
echo "\033[37;1m[===============================================]>"
sleep 1
echo "33.> Install BinGoo"
echo "\033[31;1m[===============================================]>"
sleep 1
echo "34.> Full Bot Facebook"
echo "\033[32;1m[===============================================]>"
sleep 1
echo "35.> Install Termux-A"
echo "\033[37;1m[===============================================]>"
sleep 1
echo "36.> Install Tools GadoGado"
echo "\033[36;1m[===============================================]>"
sleep 1
echo "37.> Install Lazysqlmap"
echo "\033[35;1m[===============================================]>"
sleep 1
echo "38.> Install tools diejoubu"
echo "\033[34;1m[===============================================]>"
sleep 1
echo "39.> Install weeman"
echo "\033[31;1m[===============================================]>"
sleep 1
echo "40.> Install iesDEFACE buat Deface Poc Webdav"
echo "\033[33;1m[===============================================]>"
sleep 1
echo "41.> install errorcybertools"
echo "\033[35;1m[===============================================]>"
sleep 1
echo "0.> keluar"
echo "\033[32;1m[===============================================]>"
sleep 1
echo "\033[34;1mPilih Nomer Berapa.?==>"
echo "[==============================================={>"
read bro

if [ $bro = 1 ] || [ $bro = 1 ]
then
clear
echo "\033[34;1m"
figlet "Mr.B4J1N64N"
cd
cd T00Ls-B4J1N64N2
cd module
php tp.php
fi

if
[ $bro = 2 ] || [ $bro = 2 ]
then
clear
echo "\033[31;1m"
toilet "Mr.B4J1N64N"
cd
cd T00Ls-B4J1N64N2
cd module
php t.php
fi

if [ $bro = 3 ] || [ $bro = 3 ]
then
clear
echo "\033[31;1m"
figlet "Mr.B4J1N64N"
cd
cd T00Ls-B4J1N64N2
cd module
php mataharimall.php
fi

if [ $bro = 4 ] || [ $bro = 4 ]
then
clear
echo "\033[33;1m"
toilet "Mr.B4J1N64N"
cd
cd T00Ls-B4J1N64N2
cd module
php hooq.php
fi

if [ $bro = 5 ] || [ $bro = 5 ]
then
clear
toilet -f slant --gay "Mr.B4J1N64N"
echo "\033[31;1m"
cd
cd T00Ls-B4J1N64N2
cd module
php kfc.php
fi

if [ $bro = 6 ] || [ $bro = 6 ]
then
clear
toilet -f mono12 -F gay "Mr.B4J1N64N"
echo "\033[30;1m"
cd
cd T00Ls-B4J1N64N2
cd module
php phd.php
fi

if [ $bro = 7 ] || [ $bro = 7 ]
then
clear
toilet "Mr.B4J1N64N"
cd
cd T00Ls-B4J1N64N2
cd module
php whiskas.php
fi

if [ $bro = 8 ] || [ $bro = 8 ]
then
clear
figlet "Mr.B4J1N64N"
cd
cd T00Ls-B4J1N64N2
cd module
php zipay.php
fi

if [ $bro = 9 ] || [ $bro = 9 ]
then
clear
toilet "Mr.B4J1N64N"
cd
cd T00Ls-B4J1N64N2
cd module
php key.php
fi

if [ $bro = 10 ] || [ $bro = 10 ]
then
clear
toilet "Mr.B4J1N64N"
cd
cd T00Ls-B4J1N64N2
cd module
python2 SpamMail.py
fi

if [ $bro = 11 ] || [ $bro = 11 ]
then
clear
toilet "Mr.B4J1N64N"
cd
cd T00Ls-B4J1N64N2
cd module
python2 whs.py
fi

if [ $bro = 12 ] || [ $bro = 12 ]
then
clear
toilet "Mr.B4J1N64N"
cd
cd T00Ls-B4J1N64N2
cd module
python2 upf.py
fi

if [ $bro = 13 ] || [ $bro = 13 ]
then
clear
toilet "Mr.B4J1N64N"
cd
cd T00Ls-B4J1N64N2
cd module
python2 create.py
fi

if [ $bro = 14 ] || [ $bro = 14 ]
then
clear
toilet "Mr.B4J1N64N"
cd
cd T00Ls-B4J1N64N2
ls
cd module
python2 dog.py
fi

if [ $bro = 15 ] || [ $bro = 15 ]
then
clear
toilet "Mr.B4J1N64N"
cd
cd T00Ls-B4J1N64N2
cd module
python2 gam.py
fi

if [ $bro = 16 ] || [ $bro = 16 ]
then
clear
toilet "Mr.B4J1N64N"
cd
cd T00Ls-B4J1N64N2
cd module
python2 anvima.py
fi

if [ $bro = 17 ] || [ $bro = 17 ]
then
clear
toilet "Mr.B4J1N64N"
cd
cd T00Ls-B4J1N64N2
cd module
python2 htmd.py
fi

if [ $bro = 18 ] || [ $bro = 18 ]
then
clear
toilet "Mr.B4J1N64N"
cd
cd T00Ls-B4J1N64N2
cd module
php autolike.php
fi

if [ $bro = 19 ] || [ $bro = 19 ]
then
clear
toilet "Mr.B4J1N64N"
cd
cd T00Ls-B4J1N64N2
ls
cd module
python2 auto_reaction.py
fi

if [ $bro = 20 ] || [ bro = 20 ]
then
clear
figlet "Mr.B4J1N64N" | lolcat
cd T00Ls-B4J1N64N2
cd module
python2 botkomen.py
fi

if [ $bro = 21 ] || [ $bro = 21 ]
then
clear
figlet "Mr.B4J1N64N" | lolcat
git clone https://github.com/kuburan/txtool
cd 
cd T00Ls-B4J1N64N2
cd txtool
python2 install.py
python2 update.py
txtool
fi


if [ $bro = 22 ] || [ bro = 22 ]
then
clear
toilet -f slant -F gay "Mr.B4J1N64N" 
pkg install update && pkg install upgrade
pkg install git
pkg install php
cd
cd T00Ls-B4J1N64N2
ls
clear
cd module
php sqlscan.php
fi

if [ $bro = 23 ] || [ $bro = 23 ]
then
clear
toilet -f mono12 -F gay "Mr.B4J1N64N" 
apt upgrade
apt install python2
apt install git
git clone https://github.com/UltimateHackers/Hash-Buster
cd
cd T00Ls-B4J1N64N2
cd Hash-Buster
python2 hash.py
fi

if [ $bro = 24 ] || [ $bro = 24 ]
then
clear
toilet -f standard -F gay "Mr.B4J1N64N" 
apt update
apt install git
apt install php
git clone https://github.com/Tuhinshubhra/RED_HAWK
cd 
cd T00Ls-B4J1N64N2
cd RED_HAWK
chmod +x rhawk.php
php rhawk.php
fi

if [ $bro = 25 ] || [ $bro = 25 ]
then
clear
toilet -f standard -F gay "Mr.B4J1N64N" 
apt update
apt install git
apt install tor
git clone https://github.com/dotfighter/torshammer.git
cd
cd T00Ls-B4J1N64N2
cd torshammer
python2 torshammer.py
fi

if [ $bro = 26 ] || [ $bro = 26 ]
then
clear
toilet -f standard -F gay "Mr.B4J1N64N" 
apt update
apt install git
git clone https://github.com/4L13199/LITEDDOS
cd
cd T00Ls-B4J1N64N2
cd LITEDDOS
python2 liteDDOS.py
fi

if [ $bro = 27  || [ $bro = 27 ]
then
clear
toilet -f standard -F gay "Mr.B4J1N64N" 
apt update
apt install git
git clone https://github.com/b3-v3r/Hunner.git
cd
cd T00Ls-B4J1N64N2
cd Hunner
chmod +x hunner.py
python3 hunner.py
fi

if [ $bro = 28 ] || [ $bro = 28 ]
then
clear
toilet -f standard -F gay "Mr.B4J1N64N" 
apt update
apt install git
git clone https://github.com/sqlmapproject/sqlmap
cd
cd T00Ls-B4J1N64N2
cd sqlmap
python2 sqlmap.py
fi

if [ $bro = 29 ] || [ $bro = 29 ]
then
clear
toilet -f standard -F gay "Mr.B4J1N64N" 
apt update
apt install git
git clone https://github.com/aryanrtm/4wsectools
cd
cd T00Ls-B4J1N64N2
cd 4wsectools
chmod 777 tools
./tools
fi

if [ $bro = 30 ] || [ $bro = 30 ]
then
clear
figlet "Mr.B4J1N64N" | lolcat
apt update && upgrade
apt install python2 
apt install git
cd
cd T00Ls-B4J1N64N2
cd module
python2 lazymux.py
fi

if [ $bro = 31 ] || [ $bro = 31 ]
then
clear
figlet "Mr.B4J1N64N" | lolcat
sleep 1
echo "\033[32;m====================Mempercepat / menstabilkan sinyal===================="
sleep 1
echo "\033[32;1m================================By Mr.B4J1N64N================================"
sleep 1
echo ""
echo ""
ping 8.8.8.8 
fi

if [ $bro = 32 ] || [ $bro = 32 ]
then
clear
figlet "Mr.B4J1N64N" | lolcat
sleep 1
echo "\033[32;m===================Mempercepat / menstabilkan sinyal 2===================="
sleep 1
echo "\033[32;1m================================By Mr.B4J1N64N================================"
sleep 1
echo ""
echo ""
ping -D www.google.com
fi

if [ $bro = 33 ] || [ $bro = 33 ]
then
clear
figlet "Mr.B4J1N64N" | lolcat
sleep 1
git clone https://github.com/Hood3dRob1n/BinGoo
cd T00Ls-B4J1N64N2
cd BinGoo
bash bingoo
fi

if [ $bro = 34 ] || [ $bro = 34 ]
then
clear
figlet "Mr.B4J1N64N" | lolcat
sleep 1
cd
cd T00Ls-B4J1N64N2
cd module
python2 facebook.py
fi

if [ $bro = 35 ] || [ $bro = 35 ]
then
clear
figlet "Mr.B4J1N64N" | lolcat
sleep 1
apt update && apt upgrade
apt install termux-api
apt install git
apt install php
git clone https://github.com/Cvar1984/Termux-A.git
cd
cd T00Ls-B4J1N64N2
cd Termux-A
php run.php
fi

if [ $bro = 36 ] || [ $bro = 36 ]
then
clear
figlet "Mr.B4J1N64N" | lolcat
sleep 1
apt update && apt upgrade
apt install ruby
apt install lolcat
apt install git
git clone https://github.com/Senitopeng/GadoGado.git
cd
cd T00Ls-B4J1N64N2
cd GadoGado
bash gado
fi

if [ $bro = 37 ] || [ $bro = 37 ]
then
clear
figlet "Mr.B4J1N64N" | lolcat
sleep 1
apt update && apt upgrade
apt install python2
apt install git
git clone https://github.com/verluchie/termux-lazysqlmap.git
cd
cd T00Ls-B4J1N64N2
cd termux-lazysqlmap
chmod 777 install.sh
./install.sh
lazysqlmap
fi

if [ $bro = 38 ] || [ $bro = 38 ]
then
clear
figlet "Mr.B4J1N64N" | lolcat
sleep 1 
apt install git
apt install php
git clone https://github.com/alintamvanz/diejoubu
cd
cd T00Ls-B4J1N64N2
cd diejoubu
cd v1.2
php diejoubu.php
fi

if [ $bro = 39 ] || [ $bro = 39 ]
then
clear
figlet "Mr.B4J1N64N" | lolcat
sleep 1 
apt install git
apt install php
git clone https://github.com/evait-security/weeman.git
cd
cd T00Ls-B4J1N64N2
cd weeman
python2 weeman.py
fi

if [ $bro = 40 ] || [ $bro = 40 ]
then
clear
figlet "Mr.B4J1N64N" | lolcat
sleep 1 
apt install git
apt install bash
pip2 install bash
git clone https://github.com/ALX-04/iesDEFACE
cd
cd T00Ls-B4J1N64N2
cd iesDEFACE
bash iesDeface.sh
fi

if [ $bro = 41 ] || [ $bro = 41 ]
then
clear
figlet "Mr.B4J1N64N" | lolcat
sleep 1
git clone https://github.com/MrKeepSmile/errorcybertool.git
cd 
cd T00Ls-B4J1N64N2
cd errorcybertool
chmod 77 errorcyber
cd errorcybertool
./errorcyber
fi

if [ $bro = 0 ] || [ $bro = 0 ]
then
echo "\033[32;1mWe Are Family DARKNESS CYBER TEAM"
sleep 1
echo "\033[33;1mWe Are Anonymous"
sleep 1
echo " "We Are Legion"
sleep 1
echo " "We Do Not For Give"
sleep 1
echo " "We Do Not For Get"
sleep 1
echo " "The Indonesian Anonymous Family"
sleep 1
echo " "Expect Us"
sleep 1
echo "\033[32;1m Incarlah suatu hal mustahil:) Suatu saat Kamu akan Mendapatkannya:)"
sleep 1
exit
fi